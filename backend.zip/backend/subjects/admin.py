from django.contrib import admin

from .models import Subject, LessonStage

# Register your models here.

admin.site.register(Subject)
admin.site.register(LessonStage)
