from django.apps import AppConfig


class ProgressConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "progress"
    verbose_name = "پیشرفت"
    verbose_name_plural = "پیشرفت‌ها"
